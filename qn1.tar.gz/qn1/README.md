"make" compiles both the code
"make run" runs 1a and calculates author with maximum co-author
"make run_plot" runs 1b and generates an output file that has the data needed to plot graph
